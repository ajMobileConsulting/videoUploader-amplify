//
//  VideoViewer.swift
//  videoUploader-amplify
//
//  Created by Alexander Jackson on 10/9/25.
//

import AVKit
import SwiftUI

struct VideoViewer: View {
    @Binding var url: URL
    
    var body: some View {
        VideoPlayer(player: AVPlayer(url: url))
            .frame(
                maxWidth: 300,
                maxHeight: 400,
                alignment: .center
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
