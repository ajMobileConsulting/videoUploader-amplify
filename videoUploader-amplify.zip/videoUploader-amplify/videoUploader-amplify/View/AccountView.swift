//
//  AccountView.swift
//  videoUploader-amplify
//
//  Created by Alexander Jackson on 10/9/25.
//

import Authenticator
import SwiftUI

struct AccountView: View {
    var body: some View {
        Authenticator { state in
            VStack {
                Text("AccountView()")
                Button("Sign out") {
                    Task {
                        await state.signOut()
                    }
                }
            }
        }
        .navigationTitle("Account")
    }
}

